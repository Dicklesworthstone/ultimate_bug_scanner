"""Real installation/update publication with a checksum-pinned daemon generation.

Transport and signature executables are explicit protocol doubles inherited
from release verification tests. Runner installation, hashing and CLI are real.
"""
from __future__ import annotations

import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import time
import unittest
from unittest.mock import patch

import test_verified_release as release
import test_verified_runtime_bundle as bundle

ROOT = release.ROOT


class DaemonInstallTests(unittest.TestCase):
    sign = release.VerifiedReleaseTests.sign
    fetches = release.VerifiedReleaseTests.fetches
    run_verify = release.VerifiedReleaseTests.run_verify

    def setUp(self):
        release.VerifiedReleaseTests.setUp(self)
        (self.bundle / 'install.sh').write_bytes((ROOT / 'install.sh').read_bytes())
        (self.bundle / 'ubs').write_bytes((ROOT / 'ubs').read_bytes())
        (self.bundle / 'VERSION').write_text(self.version + '\n')
        self.sign()
        self.destination = self.home / 'bin'
        self.env['UBS_INSTALLER_WORKDIR'] = str(self.root / 'installer-work')
        self.flags = ['--non-interactive', '--skip-ast-grep', '--skip-ripgrep', '--skip-jq',
                      '--skip-bun', '--skip-type-narrowing', '--skip-typos', '--skip-toon',
                      '--skip-doctor', '--skip-hooks', '--skip-version-check', '--no-path-modify',
                      '--install-dir', str(self.destination)]

    def generation(self, source=None):
        source = source or self.bundle / 'ubs-daemon'
        digest = hashlib.sha256(source.read_bytes()).hexdigest()
        return self.destination / ('ubs.daemon.' + digest + '.py')

    def invoke(self, *args, expected=0):
        result = subprocess.run([str(self.destination / 'ubs'), *args], cwd=self.project,
                                env=self.env, capture_output=True, text=True, timeout=60)
        self.assertEqual(result.returncode, expected, result.stdout + result.stderr)
        return result

    def direct_install(self, *, remote=False, expected=0):
        installer = self.bundle / 'install.sh'
        if remote:
            installer = self.root / 'standalone-install.sh'
            shutil.copy2(self.bundle / 'install.sh', installer)
        result = subprocess.run(['bash', str(installer), *self.flags], cwd=self.project,
                                env=self.env, capture_output=True, text=True, timeout=60)
        self.assertEqual(result.returncode, expected, result.stdout + result.stderr)
        return result

    def test_local_install_publishes_pair_and_canonical_commands_work(self):
        self.direct_install()
        self.assertEqual((self.destination / 'ubs').read_bytes(), (self.bundle / 'ubs').read_bytes())
        self.assertEqual(self.generation().read_bytes(), (self.bundle / 'ubs-daemon').read_bytes())
        self.assertEqual(self.generation().stat().st_mode & 0o777, 0o644)
        self.assertFalse((self.destination / 'ubs-daemon').exists())
        self.invoke('serve', '--help')
        self.invoke('--client', '--help')
        # The existing post-install health check may probe tool dependencies;
        # local release executables must never be downloaded or substituted.
        self.assertFalse({'ubs', 'ubs-daemon', 'SHA256SUMS'} & {item['name'] for item in self.fetches()})

    def test_remote_install_verifies_sidecar_against_selected_runner(self):
        self.direct_install(remote=True)
        self.assertTrue(self.generation().is_file())
        self.invoke('daemon', '--help')
        self.assertEqual([entry['name'] for entry in self.fetches()].count('ubs-daemon'), 1)

    def test_bad_local_sidecar_leaves_existing_runner_and_old_generation_usable(self):
        self.direct_install()
        before = (self.destination / 'ubs').read_bytes()
        generation = self.generation()
        original = generation.read_bytes()
        (self.bundle / 'ubs-daemon').write_bytes(original + b'\n# unexpected change\n')
        self.direct_install(expected=1)
        self.assertEqual((self.destination / 'ubs').read_bytes(), before)
        self.assertEqual(generation.read_bytes(), original)
        self.invoke('daemon', '--help')

    def test_missing_local_sidecar_does_not_fetch_or_replace_existing_runner(self):
        self.direct_install()
        before = (self.destination / 'ubs').read_bytes()
        fetches = self.fetches()
        (self.bundle / 'ubs-daemon').rename(self.bundle / 'not-the-daemon')
        self.direct_install(expected=1)
        self.assertEqual((self.destination / 'ubs').read_bytes(), before)
        self.assertEqual(self.fetches(), fetches)
        self.invoke('daemon', '--help')

    def test_bad_remote_sidecar_cannot_publish_a_runner(self):
        (self.bundle / 'ubs-daemon').write_text('raise SystemExit(99)\n')
        # The runner remains correctly signed and pinned to the original daemon.
        self.sign()
        self.direct_install(remote=True, expected=1)
        self.assertFalse((self.destination / 'ubs').exists())

    def test_symlinked_local_sidecar_is_rejected(self):
        original = self.bundle / 'saved'
        (self.bundle / 'ubs-daemon').rename(original)
        (self.bundle / 'ubs-daemon').symlink_to(original)
        self.direct_install(expected=1)
        self.assertFalse((self.destination / 'ubs').exists())

    def test_generation_destination_cannot_redirect_writes(self):
        self.destination.mkdir()
        outside = self.root / 'preserve'
        outside.write_text('unchanged')
        self.generation().symlink_to(outside)
        self.direct_install(expected=1)
        self.assertEqual(outside.read_text(), 'unchanged')
        self.assertFalse((self.destination / 'ubs').exists())

    def test_manifest_and_runner_must_agree_on_sidecar(self):
        (self.bundle / 'ubs-daemon').write_text('print("wrong release")\n')
        self.sign()
        result = self.run_verify('--verify-only', expected=1)
        self.assertIn('does not match the authenticated runner', result.stderr)
        self.assertFalse((self.destination / 'ubs').exists())

    def test_missing_signed_daemon_entry_fails_before_installation(self):
        manifest = (self.bundle / 'SHA256SUMS').read_text()
        manifest = ''.join(line for line in manifest.splitlines(True) if not line.endswith('  ubs-daemon\n'))
        self.sign(manifest=manifest)
        self.run_verify('--', *self.flags, expected=1)
        self.assertFalse((self.destination / 'ubs').exists())

    def test_signed_install_stages_daemon_and_does_not_refetch_payload(self):
        self.run_verify('--', *self.flags)
        self.invoke('daemon', '--help')
        fetched = [item['name'] for item in self.fetches()]
        self.assertEqual(fetched.count('SHA256SUMS'), 1)
        self.assertEqual(fetched.count('ubs-daemon'), 1)
        self.assertTrue(self.generation().is_file())

    def test_duplicate_or_nonliteral_runner_pin_is_rejected(self):
        original = (self.bundle / 'ubs').read_text()
        for extra in ('UBS_DAEMON_SHA256="' + '0' * 64 + '"\n',
                      'UBS_DAEMON_SHA256=$(echo malicious)\n'):
            with self.subTest(extra=extra):
                (self.bundle / 'ubs').write_text(original + '\n' + extra)
                self.direct_install(expected=1)
                self.assertFalse((self.destination / 'ubs').exists())

    def test_installer_template_matches_checkout_and_uses_canonical_client(self):
        installer = (ROOT / 'install.sh').read_text()
        template = installer.split("cat > \"$hook_file\" << 'HOOK_EOF'\n", 1)[1].split('\nHOOK_EOF', 1)[0] + '\n'
        self.assertEqual(template, (ROOT / '.claude/hooks/on-file-write.sh').read_text())
        self.assertIn('command=("$scanner" --client', template)
        self.assertIn('NOT been verified', template)

    def test_self_update_publishes_new_generation_before_switching_runner(self):
        self.direct_install()
        old_generation = self.generation()
        old_payload = old_generation.read_bytes()
        # Simulate a new signed release with a different companion pin, not a
        # changed manifest pointing back to the same generation.
        next_daemon = old_payload + b'\n# next release build\n'
        (self.bundle / 'ubs-daemon').write_bytes(next_daemon)
        old_hash = hashlib.sha256(old_payload).hexdigest()
        new_hash = hashlib.sha256(next_daemon).hexdigest()
        new_runner = (ROOT / 'ubs').read_text().replace(
            f'UBS_VERSION="{self.version}"', 'UBS_VERSION="9999.0.0"').replace(
            f'UBS_DAEMON_SHA256="{old_hash}"', f'UBS_DAEMON_SHA256="{new_hash}"')
        (self.bundle / 'ubs').write_text(new_runner)
        self.sign()
        self.env['UBS_RELEASE_BASE'] = self.env['UBS_ARTIFACT_BASE']
        self.invoke('--update')
        self.assertEqual((self.destination / 'ubs').read_text(), new_runner)
        self.assertEqual(self.generation().read_bytes(), next_daemon)
        self.assertEqual(old_generation.read_bytes(), old_payload)
        self.invoke('--client', '--help')

    def test_failed_self_update_preserves_current_generation(self):
        self.direct_install()
        before = (self.destination / 'ubs').read_bytes()
        new_runner = (ROOT / 'ubs').read_text().replace(f'UBS_VERSION="{self.version}"', 'UBS_VERSION="9999.0.0"')
        (self.bundle / 'ubs').write_text(new_runner)
        (self.bundle / 'ubs-daemon').write_text('print("tampered")\n')
        self.sign()
        self.env['UBS_RELEASE_BASE'] = self.env['UBS_ARTIFACT_BASE']
        self.invoke('--update', expected=1)
        self.assertEqual((self.destination / 'ubs').read_bytes(), before)
        self.invoke('serve', '--help')

    def test_updated_runner_receives_original_scan_arguments(self):
        self.direct_install()
        payload = (self.bundle / 'ubs-daemon').read_bytes()
        pin = hashlib.sha256(payload).hexdigest()
        (self.bundle / 'ubs').write_text(
            '#!/usr/bin/env bash\nUBS_VERSION="9999.0.0"\n'
            f'UBS_DAEMON_SHA256="{pin}"\n'
            'exec python3 -c \'import json,sys; print(json.dumps(sys.argv[1:]))\' "$@"\n')
        self.sign()
        self.env.update(UBS_RELEASE_BASE=self.env['UBS_ARTIFACT_BASE'], FORCE_SELF_UPDATE='1')
        source = self.project / 'has space.py'
        source.write_text('value = 1\n')
        flags = ['--ci', '--format=json', '--no-color', '--module-dir=' + str(ROOT / 'modules'), '--', str(source)]
        result = self.invoke(*flags)
        self.assertEqual(json.loads(result.stdout), flags)

    @unittest.skipUnless(os.environ.get('UBS_DAEMON_E2E') == '1', 'set UBS_DAEMON_E2E=1 for installed hook scanning')
    def test_installed_hook_uses_verified_service_not_a_path_replacement(self):
        import test_daemon as base
        self.env['CLAUDE_PROJECT_DIR'] = str(self.project)
        self.direct_install()
        # Non-interactive generic installation does not opt users into hook
        # registration. Explicitly exercise the real project-hook setup mode.
        subprocess.run(['git', 'init', '-q', str(self.project)], env=self.env, check=True)
        self.run_verify('--artifact-dir', str(self.bundle), '--', '--setup-claude-hook',
                        '--non-interactive', '--skip-version-check', '--no-path-modify')
        shutil.copytree(ROOT / 'modules', self.destination / 'modules')
        self.env.update(PATH=str(self.destination) + os.pathsep + self.env['PATH'],
                        ENABLE_UV_TOOLS='0', XDG_RUNTIME_DIR=str(self.root / 'runtime'))
        Path(self.env['XDG_RUNTIME_DIR']).mkdir(mode=0o700)
        planted = self.bin / 'ubs-daemon'
        marker = self.root / 'planted-executed'
        planted.write_text('#!/usr/bin/env bash\ntouch "' + str(marker) + '"\nexit 0\n')
        planted.chmod(0o755)
        source = self.project / 'edited.py'
        source.write_text('eval(input())\n')
        process = subprocess.Popen([str(self.destination / 'ubs'), 'serve', '--repo', str(self.project)],
                                   cwd=self.project, env=self.env, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        def cleanup():
            if process.poll() is None:
                process.terminate()
            process.communicate(timeout=5)
        self.addCleanup(cleanup)
        deadline = time.monotonic() + 10
        while time.monotonic() < deadline:
            status = subprocess.run([str(self.destination / 'ubs'), 'daemon', 'status', '--repo', str(self.project)],
                                    env=self.env, capture_output=True, text=True, timeout=3)
            if status.returncode == 0:
                break
            time.sleep(0.03)
        self.assertEqual(status.returncode, 0, status.stderr)
        hook = self.project / '.claude/hooks/on-file-write.sh'
        self.assertEqual(hook.read_bytes(), (ROOT / '.claude/hooks/on-file-write.sh').read_bytes())
        result = subprocess.run(['bash', str(hook)], cwd=self.project, env=self.env,
                                input=json.dumps({'tool_input': {'file_path': str(source)}}),
                                capture_output=True, text=True, timeout=130)
        self.assertEqual(result.returncode, 2, result.stderr)
        self.assertIn('found critical issues', result.stderr)
        self.assertFalse(marker.exists())
        with patch.dict(os.environ, self.env, clear=True):
            response = base.daemon.request_service(self.project, {
                'protocol': 1, 'op': 'scan', 'root': str(self.project),
                'scanner': str(self.destination / 'ubs'), 'paths': [str(source)], 'format': 'text',
                'environment': base.daemon.environment_key()}, 130)
        self.assertTrue(response['cached'], response)
        self.assertEqual(response['exit_code'], 1, response)
        print('[installed-canonical-hook] pinned generation, native findings and warm service PASS', flush=True)


class DaemonBundleTests(unittest.TestCase):
    setUp = bundle.RuntimeBundleTests.setUp
    tearDown = bundle.RuntimeBundleTests.tearDown
    tool = bundle.RuntimeBundleTests.tool
    write = bundle.RuntimeBundleTests.write
    rebuild = bundle.RuntimeBundleTests.rebuild
    seal = bundle.RuntimeBundleTests.seal
    run_verify = bundle.RuntimeBundleTests.run_verify
    events = bundle.RuntimeBundleTests.events
    export = bundle.RuntimeBundleTests.export

    def test_portable_bundle_contains_and_reverifies_signed_companion(self):
        import tarfile
        payload = (ROOT / 'ubs-daemon').read_bytes()
        self.write('ubs-daemon', payload)
        runner = (self.origin / 'ubs').read_text()
        pin = hashlib.sha256(payload).hexdigest()
        self.write('ubs', (runner + f'\nUBS_DAEMON_SHA256="{pin}"\n').encode())
        self.seal()
        output = self.work / 'portable.tar.gz'
        self.export(output)
        with tarfile.open(output) as archive:
            self.assertEqual(archive.extractfile('ubs-daemon').read(), payload)
            self.assertEqual(archive.getmember('ubs-daemon').mode, 0o755)
            unpacked = self.work / 'unpacked'
            archive.extractall(unpacked, filter='data')
        self.origin = unpacked
        self.run_verify()
        self.write('ubs-daemon', payload + b'\n# corrupt\n')
        self.run_verify(expected=1)


if __name__ == '__main__':
    unittest.main()
